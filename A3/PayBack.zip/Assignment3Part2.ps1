﻿$Host.UI.RawUI.BackgroundColor = 'White'
    $Host.UI.RawUI.ForegroundColor = 'Black'

function Bamboozle
{
    [string] $path = "."
    [string] $letter = ("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" | Get-Random)
    [string] $lowerLetter = $letter.ToLower()
    [string] $seperator = $letter + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter  + " " + $letter

    cd $path

    Get-ChildItem * -Include *$letter* -Recurse | Remove-Item -WhatIf
    Get-ChildItem * -Include *$lowerLetter* -Recurse | Remove-Item -WhatIf
    Write-Host $seperator
    Write-Host "All files containing the letter " -NoNewLine
    Write-Host $letter -NoNewLine
    Write-Host " in their name have been deleted"
}

Bamboozle