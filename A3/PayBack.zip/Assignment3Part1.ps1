﻿function KillThatProcess
{
    [string] $name = ""
    [string] $confirmation
    
    Write-Host "Enter the name of the process you would like to stop."
    $name = Read-Host

    [int] $numInstinces = 0
    $numInstinces = @(Get-Process -ea SilentlyContinue $name).Count

    if($numInstinces -ne 0) 
    {
        Write-Host "There is/are " -NoNewline
        Write-Host $numInstinces -NoNewline
        Write-Host " processe(s) with the name " -NoNewline
        Write-Host $name -NoNewline
        Write-Host ", proceed? Y/N"
        $confirmation = Read-Host

        if($confirmation.ToLower() -eq 'y') 
        {
            Stop-Process -Name $name
            Write-Host $name -NoNewline
            Write-Host " was successfuly closed"
        }
        else
        {
            Write-Host "KillThatProcess successfuly canceled"
        }
    }

    else
    {
        Write-Host "There is no process with the name " -NoNewline
        Write-Host $name -NoNewline
	Write-Host "running on the device"
    }
}

KillThatProcess